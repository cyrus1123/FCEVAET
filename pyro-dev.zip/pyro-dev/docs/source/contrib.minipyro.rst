Minipyro
========
.. automodule:: pyro.contrib.minipyro
    :members:
    :undoc-members:
    :special-members: __call__
    :show-inheritance:
